---
type: moc
tags: [moc, project, reglasses, wq7036ax]
---

# 90-Projects: reGlasses 智能眼镜 (WQ7036AX + V881)

> 当前项目。WQ7036AX 双模蓝牙音频 SoC + 全志 V881 主控 Linux SoC。

## 项目总览

| 文件 | 说明 |
|------|------|
| [[reGlasses 协议架构]] | 三方通信拓扑 (WQ7036AX ↔ V881 ↔ 手机) |
| [[reGlasses 带宽约束]] | 双模蓝牙 (HFP/A2DP/BLE) + WiFi 带宽分配 |
| [[reGlasses 学习计划]] | 8 周分阶段学习路线 |

## Architecture (架构设计)

| 文件 | 说明 |
|------|------|
| [[reGlasses GATT Service 设计]] | BLE GATT 7 个 Characteristic 定义 |
| [[reGlasses 扩展命令集]] | WQ Protocol 新增 4 类 Service |
| [[reGlasses 跨芯片指令转发]] | BLE → WQ7036AX → UART → V881 路由 |

## Protocol (协议细节)

| 文件 | 说明 |
|------|------|
| [[WQ Audio Protocol]] | 0x5751 帧协议 |
| [[WQ Protocol 帧结构]] | bit-level 详解 |
| [[WQ Protocol 服务类型]] | 已有 + 新增命令 ID |
| [[帧协议对比：UART 命令协议 vs WQ Protocol]] | 两种帧格式对比 |

## DataFlow (数据流追踪)

| 文件 | 说明 |
|------|------|
| [[数据流：声音从麦到手机]] | PDM → PCM → DSP → Opus → BLE |
| [[数据流：手机指令到 V881]] | BLE Write → WQ Protocol → UART CMD → V881 |

## 硬件外设

| 文件 | 说明 |
|------|------|
| [[WQ7036AX 芯片]] | 三核架构/引脚/电源域 |
| [[WQ7036AX 音频管道]] | 完整音频处理链 |
| [[ELM2713 光传感器]] | I2C 光/近程传感器 (0x39) |
| [[MAX98357A 功放]] | I2S 输入 Class-D 功放 |
| [[SDM0103B 数字麦]] | PDM 数字麦克风 ×4 |
| [[Ext Trans 框架]] | SDK 可插拔 IO + Protocol 架构 |

## Snippets (代码片段)

| 文件 | 说明 |
|------|------|
| [[Snippet - BLE GATT Service 注册模板]] | GATT Service 注册代码 |
| [[Snippet - I2C 读写寄存器]] | I2C 设备寄存器操作 |
| [[Snippet - WQ Protocol 帧打包解包]] | WQ Protocol pack/unpack |

## 归档 (已弃用)

| 文件 | 说明 |
|------|------|
| _archive-STTP/ | STTP 协议已弃用，保留作为历史参考 |
