---
type: moc
tags: [moc, bsp, devicetree, uboot, kernel, buildroot]
---

# 30-BSP: 板级支持包

> JD 能力域 5。BSP 工程师的核心工作：让 Linux 在你的板子上跑起来。

## 已有笔记

| 文件 | 核心主题 |
|------|----------|
| [[启动流程与 OTA 升级]] | BootROM → U-Boot → Kernel → 根文件系统 + A/B OTA |

## 待创建

| 主题 | 预期内容 |
|------|----------|
| DeviceTree | DTS 语法、常用节点 (gpio/i2c/spi/pinmux)、overlay、调试 |
| U-Boot | 启动流程、环境变量、常用命令、自定义命令、SPL |
| Kernel 裁剪与编译 | defconfig/menuconfig、模块编译、设备驱动使能 |
| Buildroot/Yocto | 交叉编译工具链、根文件系统定制、包管理 |
| 电源与引脚复用 | pinctrl 子系统、regulator、clock framework、休眠唤醒 |

## 面试高频问题

- DeviceTree 中 `compatible` 字段的作用？
- U-Boot 的 bootcmd 和 bootargs 怎么配？
- 内核模块的 init/exit 函数什么时候执行？
- Buildroot 和 Yocto 的核心区别？
- pinctrl 和 gpio 子系统的关系？
