---
type: moc
tags: [moc, application, posix, ipc, systemd, network]
---

# 50-Application: 应用层开发

> JD 能力域 7。Linux 用户空间程序——守护进程、网络通信、多媒体 pipeline。

## 待创建

| 主题 | 预期内容 |
|------|----------|
| 多线程/POSIX | pthread/mutex/cond/信号/线程池 |
| IPC | 共享内存/消息队列/D-Bus/Unix Socket/管道 |
| systemd 守护进程 | unit 文件/journalctl/依赖管理/自动重启 |
| 网络编程 | TCP/UDP Socket/MQTT/HTTP/REST API |
| GStreamer | Pipeline/Element/Pad/Caps、音频视频处理 |

## 面试高频问题

- pthread_mutex 和 pthread_cond 怎么配合使用？
- 共享内存和消息队列的优缺点？
- D-Bus 的 signal 和 method call 区别？
- systemd unit 文件中 Restart=always 的作用？
- select/poll/epoll 的区别？
