---
type: moc
tags: [moc, multimedia, audio, video, gstreamer, ai]
---

# 60-Multimedia-AI: 多媒体与 AI

> JD 能力域 8。音频/视频/AI 是 reGlasses 等智能设备的核心功能。

## 已有笔记

| 文件 | 核心主题 |
|------|----------|
| [[音频系统基础]] | 采样率/位深/PCM/I2S/PDM/AEC/Opus |
| [[Opus 编码]] | Opus 编解码器参数与使用 |

## 待创建

| 主题 | 预期内容 |
|------|----------|
| 视频系统 | H.264/H.265 编码、ISP 图像处理、V4L2 应用 |
| GStreamer pipeline | 音频/视频处理链、自定义 element |
| AI 推理 | OpenCV 基础、TensorFlow Lite 部署、模型优化 |
