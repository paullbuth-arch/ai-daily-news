---
type: moc
tags: [moc, bluetooth, ble, hfp, a2dp, gatt]
---

# 70-Bluetooth: 蓝牙协议栈

> JD 能力域 9。WQ7036AX 是双模蓝牙芯片，经典蓝牙和 BLE 都要懂。

## 已有笔记

### BLE

| 文件 | 核心主题 |
|------|----------|
| [[BLE GAP 广播]] | 广播包/扫描/连接建立 |
| [[BLE GATT]] | Service/Characteristic/Read/Write/Notify |
| [[BLE GATT Service]] | reGlasses 自定义 7 个 Characteristic |
| [[BLE SMP 配对]] | Just Works/绑定/加密 |
| [[无线对比：BLE vs WiFi]] | BLE vs WiFi 带宽/功耗/适用场景 |

### 经典蓝牙

⬜ 待创建：HFP (通话) / A2DP (音乐) / AVRCP (媒体控制) / SPP (串口)

### 蓝牙调试

⬜ 待创建：HCI log / btmon / Wireshark 蓝牙抓包

## 面试高频问题

- BLE 广播包最大多少字节？
- GATT 中 Service 和 Characteristic 的关系？
- HFP SCO 和 BLE GATT 的区别？为什么通话用 HFP？
- BLE 配对方式有哪些？Just Works 和 Passkey 的区别？
- A2DP 支持哪些编解码器？
