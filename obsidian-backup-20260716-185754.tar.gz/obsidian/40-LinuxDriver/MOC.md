---
type: moc
tags: [moc, linux, driver, platform, alsa, v4l2]
---

# 40-LinuxDriver: Linux 驱动开发

> JD 能力域 6。Linux 驱动是 BSP 工程师的核心产出——让硬件在 Linux 下可用。

## 已有笔记

| 文件 | 核心主题 |
|------|----------|
| [[外设驱动通用框架]] | platform_driver/probe/remove/device_tree 匹配 |

## 待创建

| 主题 | 预期内容 |
|------|----------|
| 字符设备 / ioctl | cdev/file_operations/ioctl 接口、udev 规则 |
| Input 子系统 | input_dev/input_event、按键/触摸屏上报 |
| I2C/SPI/GPIO 子系统 | i2c_client/spi_device/gpiod API |
| ALSA ASoC 音频 | DAI/Codec/Platform/Machine 四件套、DMA 音频 |
| V4L2 摄像头 | v4l2_device/video_device/vb2 队列、MIPI CSI |
| DRM/KMS 显示 | CRTC/Encoder/Connector/Plane、framebuffer |
| WiFi/BLE 网络驱动 | cfg80211/mac80211/SDIO/USB gadget |
| DMA/中断/PM | DMA 映射/request_irq/runtime_pm/suspend/resume |

## 面试高频问题

- platform_driver 的 probe 函数什么时候被调用？
- i2c_driver 和 i2c_client 的关系？
- ALSA ASoC 中 DAI、Codec、Platform 各负责什么？
- V4L2 的 buffer 管理 (vb2) 怎么工作？
- DMA 映射的 dma_map_single 和 dma_map_sg 区别？
- runtime PM 和 system PM 的区别？
