---
type: concept
created: 2026-07-16
tags: [protocol, i2s, audio, pcm, 音频总线]
aliases: [I2S, Inter-IC Sound, I²S]
---

# I2S 协议

## 一句话理解

I2S (Inter-IC Sound，芯片间音频总线) 就像**一条音频流水线**：3 根线 (BCLK 节拍 + LRCK 左右切换 + DATA 数据) 把 PCM (Pulse Code Modulation，脉冲编码调制) 音频数据从一个芯片搬到另一个芯片，不需要打包、不需要地址，纯粹的音频搬运工。

## 为什么学它

reGlasses 有两路 I2S：
1. **I2S #1**：WQ7036AX ↔ V881 — 音频数据双向交换
2. **I2S #2**：WQ7036AX → MAX98357A 功放 → 双扬声器

不懂 I2S，你就不知道音频数据是怎么从 WQ7036AX 送到扬声器的。

## 第一步：在 Source Insight 中找到 I2S 配置

1. **`Ctrl+Comma`** 搜索 `CONFIG_EXT_TRANS_I2S_SAMPLE_RATE` → 看 Kconfig 配置
2. 当前值：`16000` (16kHz 采样率)
3. 搜索 `CONFIG_EXT_TRANS_I2S_DATA_FORMAT` → 值 `0` = Philips I2S 标准格式
4. 搜索 `CONFIG_EXT_TRANS_I2S_MASTER_ENABLE` → 值 `0` = Slave 模式 (V881 是 Master)

这些配置决定了 I2S 的工作方式：

| 配置项 | 当前值 | 含义 |
|--------|--------|------|
| SAMPLE_RATE | 16000 | 采样率 16kHz |
| DATA_FORMAT | 0 | Philips 标准 I2S |
| MASTER_ENABLE | 0 | WQ7036AX 为 Slave (V881 提供时钟) |
| TRANS_DIR | 2 | 双向 (发送+接收) |

## 第二步：理解 3 根线

```
           LRCK (帧时钟 / Word Select)
       ┌───────────┐               ┌───────────┐
       │           │               │           │
  ─────┘           └───────────────┘           └─────
  ↑ LRCK 高 = 左声道数据           ↑ LRCK 低 = 右声道数据

  BCLK: ╱╲╱╲╱╲╱╲╱╲╱╲╱╲╱╲╱╲╱╲╱╲╱╲  (位时钟，每一位一个脉冲)

  DATA:  xx│L15│L14│...│L0│xx│R15│R14│...│R0│
       ↑                            ↑
    BCLK 上升沿采样              BCLK 上升沿采样
```

- **BCLK** (Bit Clock，位时钟)：每个脉冲搬 1 个 bit
- **LRCK** (Left-Right Clock，左右声道时钟)：高电平 = 左声道，低电平 = 右声道
- **DATA** (串行数据)：MSB (Most Significant Bit，最高位) 先发

### 时钟频率关系

```
Fs (采样率) = 16000 Hz
LRCK = Fs = 16 kHz
BCLK = 2 × 位宽 × Fs = 2 × 16 × 16000 = 512 kHz
MCLK (可选) = 256 × Fs = 4.096 MHz
```

详见 [[I2S 时钟树]]。

## 第三步：Master vs Slave

| 角色 | 谁提供 BCLK/LRCK | reGlasses 使用 |
|------|-----------------|---------------|
| **Master** (主) | 本端芯片 | I2S #2 (WQ7036AX → 功放) |
| **Slave** (从) | 对端芯片 | I2S #1 (V881 提供时钟) |

Slave 不需要生成时钟，只需要**跟着 Master 的节拍**收发数据。

## reGlasses 中的两路 I2S

### I2S #1 — WQ7036AX ↔ V881

```
V881 (Master)                    WQ7036AX (Slave)
  BCLK ──────────────────────────→ A17
  LRCK ──────────────────────────→ B15
  DOUT ────(PCM audio)──────────→ D17 (DIN0)
  DIN  ←───(PCM audio)──────────  B16 (DOUT0)
```

### I2S #2 — WQ7036AX → MAX98357A 功放

```
WQ7036AX (Master)           MAX98357A U16 (左)    MAX98357A U17 (右)
  AMP_I2S_BCLK ────────────→ BCLK                → BCLK
  AMP_I2S_LRCLK ───────────→ LRCLK               → LRCLK
  AMP_I2S_DOUT ────────────→ DIN                  → DIN
                             AMP1_OUTP/N           AMP2_OUTP/N
                             → 左扬声器             → 右扬声器
```

两颗功放共享一条 I2S 总线，通过 LRCK 区分左右声道。详见 [[MAX98357A 功放]]。

## 验收标准

- [ ] 能说出 I2S 的 3 根核心信号线 (BCLK/LRCK/DATA) 各自的作用
- [ ] 能算出 16kHz/16-bit 时的 BCLK 频率 (512kHz)
- [ ] 能区分 Master 和 Slave 模式
- [ ] 能说出 reGlasses 两路 I2S 各自的 Master 是谁

## 关联概念

- [[I2S 时钟树]] — MCLK/BCLK/LRCK 频率关系详解
- [[PDM 麦克风]] — 对比：PDM 只需 2 根线，I2S 需 3 根
- [[MAX98357A 功放]] — I2S #2 的接收端
- [[WQ7036AX 音频管道]] — I2S 在完整音频链中的位置
- [[音频接口对比：I2S vs PDM]] — 两种音频接口全面对比

#flashcard
问：I2S 的 3 根核心信号线是什么？
答：BCLK (位时钟)、LRCK (左右声道选择/帧时钟)、DATA (串行音频数据)。

问：16kHz 采样率、16-bit 位宽时 BCLK 频率是多少？
答：512 kHz = 2 × 16 × 16000。

问：reGlasses 中 I2S #1 的 Master 是谁？
答：V881 是 Master (提供 BCLK 和 LRCK)，WQ7036AX 是 Slave (跟随 V881 的时钟)。
