---
type: moc
tags: [moc, hardware, protocol, UART, I2C, SPI, I2S, PDM]
---

# 20-HardwareProtocol: 硬件协议

> JD 能力域 4。嵌入式工程师的"语言"——你得看懂 datasheet 里的时序图，能配置寄存器让外设跑起来。

## UART / I2C / SPI / GPIO

| 文件 | 核心主题 |
|------|----------|
| [[UART 基础]] | 异步串口：TX/RX/波特率/帧格式 |
| [[UART 命令协议]] | reGlasses 当前使用的 UART 帧协议 (app_uart_cmd) |
| [[I2C 基础]] | 两线总线：地址/Start/Stop/寄存器读写 |
| [[GPIO 配置]] | 输入/输出/中断/复用功能 |
| [[串口总线对比：UART vs I2C vs SPI]] | 三种总线全面对比 |

## I2S / PDM / 音频接口

| 文件 | 核心主题 |
|------|----------|
| [[I2S 协议]] | 3 线音频总线：BCLK/LRCK/DATA |
| [[I2S 时钟树]] | MCLK/BCLK/LRCK 频率关系 |
| [[PDM 麦克风]] | 1-bit 密度调制：2 线音频采集 |
| [[音频接口对比：I2S vs PDM]] | 两种接口选择依据 |

## MIPI / USB / SDIO

⬜ 待创建 — 用到时再补。
