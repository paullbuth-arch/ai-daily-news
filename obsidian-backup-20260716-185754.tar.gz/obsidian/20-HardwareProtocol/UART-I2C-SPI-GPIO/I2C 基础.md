---
type: concept
created: 2026-07-16
tags: [protocol, i2c, bus, sensor, 总线, 传感器]
aliases: [I2C, IIC, Inter-Integrated Circuit]
---

# I2C 基础

## 一句话理解

I2C (Inter-Integrated Circuit，芯片间通信总线) 就像**教室里的点名制度**：老师 (Master，主机) 喊一个学号 (Address，地址)，被点到的学生 (Slave，从机) 站起来回答问题。只有两根线——一根用来喊话 (SCL 时钟)，一根用来传答案 (SDA 数据)。

## 为什么学它

reGlasses 有两个 I2C 设备需要你驱动：
1. **[[ELM2713 光传感器]]** — 检测环境光 + 佩戴检测 (眼镜是否在头上)
2. **颈环充电 IC** — 读取充电状态 (电量、是否充满)

I2C 比 UART 多了一个"地址"概念，比 SPI 少两根线，是最常用的传感器接口。

## 第一步：在 Source Insight 中找到 I2C 驱动

1. **`Ctrl+Comma`** 搜索 `wq_i2c_init` → 跳到 `wq_i2c.c`
2. 看初始化流程——和 UART 类似，使能时钟 + 配置引脚

```c
// I2C 写操作
WQ_RET wq_i2c_write(WQ_I2C_PORT port, uint8_t addr,
                    uint8_t reg, const uint8_t *data, uint8_t len);

// I2C 读操作
WQ_RET wq_i2c_read(WQ_I2C_PORT port, uint8_t addr,
                   uint8_t reg, uint8_t *buf, uint8_t len);
```

关键参数：
- `port` — 用哪个 I2C 控制器 (0 或 1)
- `addr` — 从设备地址 (7-bit，如 ELM2713 = **0x39**)
- `reg` — 要读写的寄存器 (Register) 地址

## 第二步：理解物理层

```
         3.3V        3.3V
          │           │
         [R]         [R]    ← 上拉电阻 (Pull-up Resistor, 4.7kΩ)
          │           │
SCL ──────┼───────────┼──── Master + 所有 Slave
SDA ──────┼───────────┼──── Master + 所有 Slave
          │           │
       ┌──┴──┐    ┌──┴──┐
       │Master│    │Slave│
       │(主机) │    │(从机) │
       └─────┘    └─────┘
```

- **SCL** (Serial Clock，串行时钟)：Master 驱动，告诉 Slave "现在该采样了"
- **SDA** (Serial Data，串行数据)：双向，发送方拉低，接收方读
- **上拉电阻 (Pull-up)**：把线拉高到 3.3V，因为 I2C 只能**拉低**，不能主动拉高

### Start 和 Stop 条件

```
Start (开始): SCL 高电平时 SDA 从高→低
Stop  (结束): SCL 高电平时 SDA 从低→高

     SCL: ───────╱─╲─╱─╲─╱─╲───────
     SDA: ──╲   D7  D6  D5  ... ────
          Start
```

## 第三步：理解读写流程

### 写一个寄存器

```
Master → [Start] [地址+W] [ACK] [寄存器] [ACK] [数据] [ACK] [Stop]
```

用 ELM2713 举例 (地址 **0x39**, 写寄存器 0x10 = 0x03)：
```
[S] [0x72] [A] [0x10] [A] [0x03] [A] [P]
 │   │      │   │      │   │      │   │
 │   │      │   │      │   │      │   └─ Stop (结束)
 │   │      │   │      │   │      └───── ACK (Slave 说"收到了")
 │   │      │   │      │   └──────────── 数据 0x03
 │   │      │   │      └──────────────── ACK
 │   │      │   └─────────────────────── 寄存器地址 0x10
 │   │      └─────────────────────────── ACK
 │   └────────────────────────────────── 地址+W (0x39<<1 | 0 = 0x72)
 └────────────────────────────────────── Start (开始)
```

### 读一个寄存器

```
Master → [Start] [地址+W] [ACK] [寄存器] [ACK] [Restart] [地址+R] [ACK] [数据] [NACK] [Stop]
```

读的时候**多了一步 Restart** (重新开始)：先"假装写"告诉 Slave 要读哪个寄存器，然后重新 Start 切换为读模式。

## reGlasses 中的两路 I2C

### I2C #1 — ELM2713

| 参数 | 值 |
|------|------|
| WQ7036AX 引脚 | SCK=A10, SDA=A9 |
| 从设备 | [[ELM2713 光传感器]] (U18) |
| 地址 | **0x39** (7-bit, `elm2713_sensor.c` 确认) |
| 中断 | LS_INT (M12) |

### I2C #2 — 颈环充电 IC

| 参数 | 值 |
|------|------|
| WQ7036AX 引脚 | SCK=B8, SDA=B7 |
| 连接器 | J27 (SCK), J28 (SDA) |
| 中断 | TWS_CHARGE_INT (M11) |

## 与 UART/SPI 对比

| | UART | I2C | SPI |
|---|---|---|---|
| 线数 | 2 (TX+RX) | 2 (SDA+SCL) | 4 (MOSI/MISO/SCK/CS) |
| 寻址 | 无 (点对点) | **地址 (7/10-bit)** | 片选 (CS) |
| 双工 | 全双工 | **半双工** (同一根 SDA) | 全双工 |
| 速度 | 115200 bps | **100k/400k** | 数十 MHz |
| 设备数 | 1 对 1 | **1 对多 (地址区分)** | 1 对多 (CS 区分) |

## 验收标准

- [ ] 能在 SI 中找到 `wq_i2c.c` 并说出 `wq_i2c_write` / `wq_i2c_read` 的参数含义
- [ ] 能画出 I2C 写寄存器的时序：Start → 地址+W → ACK → 寄存器 → ACK → 数据 → ACK → Stop
- [ ] 能解释为什么 I2C 需要上拉电阻 (只能拉低不能拉高)
- [ ] 能说出 reGlasses 两路 I2C 各自连了什么设备

## 关联概念

- [[ELM2713 光传感器]] — I2C #1 的从设备
- [[I2S 协议]] — 对比：I2S 是音频专用，I2C 是通用传感器
- [[UART 基础]] — 对比：UART 无地址，I2C 有地址
- [[Snippet - I2C 读写寄存器]] — 代码模板
- [[串口总线对比：UART vs I2C vs SPI]] — 三种总线全面对比

#flashcard
问：I2C 的 Start 和 Stop 条件分别是什么？
答：Start = SCL 高电平时 SDA 从高→低。Stop = SCL 高电平时 SDA 从低→高。

问：I2C 读寄存器为什么要 Restart？
答：先写寄存器地址告诉 Slave 要读哪里（假装写），然后 Restart 切换到读模式，Slave 才开始发数据。

问：reGlasses 中 I2C #1 连了什么设备？地址是多少？
答：ELM2713 光/近程传感器，地址 **0x39** (7-bit)，中断引脚 LS_INT (M12)。
