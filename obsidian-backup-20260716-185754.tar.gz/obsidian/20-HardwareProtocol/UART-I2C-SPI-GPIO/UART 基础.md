---
type: concept
created: 2026-07-16
tags: [protocol, uart, serial, async, 串口, 异步]
aliases: [UART, 串口, Universal Asynchronous Receiver-Transmitter]
---

# UART 基础

## 一句话理解

UART (Universal Asynchronous Receiver-Transmitter，通用异步收发器) 就像**两个人用对讲机说话**：约定好语速（波特率），一个人嘴巴（TX）对另一个人的耳朵（RX），各说各听，不用同时对表。

## 为什么先学它

UART 是所有协议里**最简单**的——只有两根线，没有时钟，没有地址，没有复杂的帧格式。WQ7036AX 和 V881 之间的所有通信都跑在 UART 上（上层套了 [[STTP 协议]]）。**搞懂 UART，后面看 STTP 就轻松一半。**

## 第一步：在 Source Insight 中找到 UART 驱动

1. **`Ctrl+Comma`** 搜索 `wq_uart_init` → 跳到 `wq_uart.c`
2. 这是 UART 初始化的入口，看函数体：
```c
void wq_uart_init(WQ_UART_PORT port)
{
    // 先初始化内存
    if (wq_uart_status.mem_initialized == 0) {
        uart_init_mem();
        wq_uart_status.mem_initialized = 1;
    }
    // 再初始化具体端口
    if ((wq_uart_status.port_initialized & BIT(port)) == 0) {
        uart_init(port);  // ← 跳进去看底层
        ...
    }
}
```
3. **`Ctrl+Click`** 跳进 `uart_init(port)` → 到了 `uart.c`（硬件层）
4. 这里能看到时钟使能 (`apb_clk_enable`) 和 FIFO 初始化

> 💡 **Source Insight 技巧**：按 `F12` 查看函数的调用关系（谁调用了它），按 `Ctrl+G` 跳转到指定行号。

## 第二步：理解 UART 的物理层

```
WQ7036AX                    V881
  TX (GPIO50) ────────────→ RX
  RX (GPIO51) ←──────────── TX
  GND ───────────────────── GND
```

**两根线 + 地线**，就这么简单：
- **TX** (Transmit，发送)：我的嘴巴 → 你的耳朵 (RX)
- **RX** (Receive，接收)：我的耳朵 ← 你的嘴巴 (TX)
- **交叉连接**：A.TX → B.RX，A.RX ← B.TX

### 数据帧长什么样

```
空闲(高) ──┐  D0 D1 D2 D3 D4 D5 D6 D7 ┌── 空闲(高)
           │                           │
           └─ Start ─── 8 Data Bits ─── Stop ─
             (低)                      (高)
```

- **空闲状态**：线拉高（1）
- **Start bit** (起始位)：拉低（0），告诉对方"我要说话了"
- **8 个 Data bits** (数据位)：一个字节，低位先发
- **Stop bit** (停止位)：拉高（1），"我说完了"

### reGlasses 的配置

| 参数 | 值 | 类比 |
|------|------|------|
| 波特率 (Baud Rate) | 115200 | 语速：每秒说 115200 个 bit |
| 数据位 (Data Bits) | 8 | 每次说一个字节 |
| 校验 (Parity) | None | 不做校验 |
| 停止位 (Stop Bits) | 1 | 一个停止位 |

## 第三步：看发送和接收

在 SI 搜索 `wq_uart_write`：

```c
WQ_RET wq_uart_write(WQ_UART_PORT port, const char *string,
                     uint32_t length, wq_uart_write_done_callback cb)
{
    // 如果前面没有排队的数据，直接往 FIFO 里写
    if (wq_uart_status.port[port].tx.head == NULL) {
        wsize = wq_uart_write_fifo(port, string, length);
        if (wsize == length) {
            // 全写完了，直接回调
            if (cb != NULL) cb(string, length);
            return WQ_RET_OK;
        }
    }
    // 写不完？排到链表里，等 TX FIFO 空了再发
    wq_uart_tx_block_t *block = wq_tx_block_alloc();
    block->buffer = string;
    block->length = length;
    // ... 加入链表，开中断
}
```

**关键概念**：
- **FIFO** (First In First Out，先入先出队列)：硬件缓冲区，CPU 往里写数据，硬件自动一位一位发出去
- **中断** (Interrupt)：FIFO 空了会自动通知 CPU "我又饿了，再给我数据"
- **DMA** (Direct Memory Access，直接内存访问)：大数据量时可以绕过 CPU，让 DMA 直接搬数据到 FIFO

搜索 `wq_uart_register_rx_callback` 看接收侧：

```c
// 注册接收回调：当收到数据时，自动调用你的函数
WQ_RET wq_uart_register_rx_callback(WQ_UART_PORT port,
    uint8_t *buffer, uint32_t length, wq_uart_rx_callback callback)
```

## UART vs I2C vs SPI（快速对比）

| | UART | [[I2C 基础\|I2C]] | SPI |
|---|---|---|---|
| 线数 | 2 (TX+RX) | 2 (SDA+SCL) | 4 (MOSI/MISO/SCK/CS) |
| 同步/异步 | **异步** (无时钟线) | 同步 (有时钟线 SCL) | 同步 |
| 寻址 | 无 (点对点) | 地址寻址 | 片选 (CS) |
| 速度 | 115200 bps 典型 | 100k/400k bps | 数十 MHz |
| reGlasses 用途 | 连 V881 (STTP) | 连 ELM2713、充电IC | 未使用 |

## 验收标准

- [ ] 能在 SI 中找到 `wq_uart.c` 并说出 `wq_uart_init` / `wq_uart_write` 的作用
- [ ] 能画出 UART 帧结构：Start → 8 Data → Stop
- [ ] 能解释为什么 TX 和 RX 要交叉连接
- [ ] 能说出 reGlasses 中 UART 的波特率 (115200) 和连接对象 (V881)

## 下一步

UART 搞懂了 → 去看 [[STTP 协议]] — UART 只是公路，STTP 是跑在上面的快递公司。

## 关联概念

- [[STTP 协议]] — UART 上层跑的可靠传输协议
- [[I2C 基础]] — 对比：另一种两线总线
- [[WQ7036AX 芯片]] — UART 控制器引脚：TX=GPIO50, RX=GPIO51

#flashcard
问：UART 为什么叫"异步"通信？
答：因为没有时钟线。发送方和接收方必须预先约定相同的波特率 (Baud Rate)，通过 Start bit 对齐采样时机。

问：reGlasses 中 UART 连接哪两个芯片？波特率是多少？
答：连接 WQ7036AX (GPIO50/51) 和 V881。波特率 115200，8 数据位，无校验，1 停止位 (8N1)。

问：UART 的 TX 和 RX 怎么连？
答：交叉连接：A.TX → B.RX，A.RX ← B.TX。TX 是"嘴巴"，RX 是"耳朵"，嘴巴对耳朵。
