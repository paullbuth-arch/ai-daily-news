---
type: concept
created: 2026-07-16
tags: [mcu, gpio, peripheral, 引脚, 按键, LED, 中断]
aliases: [GPIO, General Purpose Input/Output, 通用IO]
---

# GPIO 配置

## 一句话理解

GPIO (General Purpose Input/Output，通用输入输出口) 就是芯片上**最基础的"开关"引脚**——你可以把它设为"输入"读按钮有没有被按下，或设为"输出"来控制 LED 亮不亮。所有复杂协议 (UART/I2C/I2S) 的引脚都是从 GPIO "变身"而来的。

## 为什么学它

reGlasses 的 3 个按键、RGB LED、光传感器中断、充电中断——全靠 GPIO。这是你**最先需要调通**的外设，因为按键和 LED 是验证其他功能是否正常的"眼睛和手"。

## 第一步：在 Source Insight 中找到 GPIO 驱动

1. **`Ctrl+Comma`** 搜索 `gpio_set_func` → 跳到 GPIO 驱动文件
2. 看核心 API：

```c
// 设置引脚功能 (普通GPIO 还是复用为UART/I2C等)
gpio_set_func(pin, GPIO_FUNC_NORMAL_GPIO);  // 普通 GPIO
gpio_set_func(pin, GPIO_FUNC_UART_TX);      // 复用为 UART TX

// 设置方向
gpio_set_direction(pin, GPIO_DIR_INPUT);    // 输入 (读按键)
gpio_set_direction(pin, GPIO_DIR_OUTPUT);   // 输出 (控LED)

// 设置上下拉
gpio_set_pull(pin, GPIO_PULL_UP);           // 内部上拉 (按键需要)

// 读写电平
gpio_set_level(pin, 1);                     // 输出高电平 (点亮LED)
uint8_t level = gpio_get_level(pin);        // 读输入电平 (按键状态)

// 注册中断回调
gpio_register_interrupt(pin, GPIO_INT_FALLING, callback, arg);
```

## reGlasses GPIO 映射

### 按键 (输入，上拉，低电平有效)

```
  3.3V
   │
  [R] ← 上拉电阻 (Pull-up, 内部或外部)
   │
   ├──── KEY_1 (M14) → WQ7036AX
   │
  [按键]
   │
  GND
```

- **没按**：读到高电平 (1)
- **按下**：按键接通 GND，读到低电平 (0)
- **防抖 (Debounce)**：按键按下瞬间会有弹跳，需要软件延时 20-50ms 确认

| 按键 | 引脚 | 功能 | 需求书操作 |
|------|------|------|-----------|
| KEY_1 | M14 | 功能键 A | 长按1s=录制, 单击=拍照, 双击=切镜头, 三击=TOF |
| KEY_2 | M5 | 功能键 B | 单击=语音, 双击=播报状态, 长按1s=录音, 长按5s=配网 |
| KEY_3 | N6 | 电源键 | 长按2s=开关机 |

### LED (输出，推挽)

| LED | 引脚 | 颜色 | 用途 |
|-----|------|------|------|
| LED_R | N10 | 红 | 录制中 / 警告 |
| LED_G | M10 | 绿 | 开机 / 正常 / 充满 |
| LED_B | N11 | 蓝 | 配网模式 / 蓝牙 |

LED 组合可以产生多种颜色：红+蓝=紫，红+绿=黄，全开=白。

### 中断输入

| 信号 | 引脚 | 来源 | 触发方式 |
|------|------|------|----------|
| LS_INT | M12 | [[ELM2713 光传感器]] | 低电平 (佩戴检测) |
| TWS_CHARGE_INT | M11 | 充电 IC | 下降沿 (充电状态变更) |
| GPOUT_FG | M9 | 电量计 | 下降沿 (电量变化) |
| FAULT | E9 | 电源管理 | 低电平 (故障) |

### 控制信号

| 信号 | 引脚 | 方向 | 用途 |
|------|------|------|------|
| PS_EN | J9 | 输出 | 电源使能 (开/关电源芯片) |
| TWS_BOOT | B12 | 输出 | 启动模式 (刷固件时拉低) |
| BT-WK-V881 | M13 | 输出 | BLE 唤醒 V881 (低功耗唤醒) |
| SOC-PWR-ON | Q10 | 输出 | SoC 电源控制 (MOSFET 开关) |

## 按键识别逻辑 (短按/长按/双击)

```
按下 ──→ 20ms 防抖 ──→ 确认按下
                            │
                      等待释放
                            │
                    ┌───────┼───────┐
                    ↓       ↓       ↓
              短按(<1s)  长按(>1s)  双击(300ms内再按)
```

SDK 的按键组件 (key) 会自动做这些识别，你只需要注册回调。

## 验收标准

- [ ] 能在 SI 中找到 GPIO 驱动并说出 `gpio_set_func` / `gpio_set_direction` / `gpio_set_level` 的用途
- [ ] 能解释按键为什么需要上拉电阻和防抖
- [ ] 能列出 reGlasses 的 3 个按键引脚和功能
- [ ] 能区分 GPIO 的输入/输出/中断三种模式

## 关联概念

- [[WQ7036AX 芯片]] — GPIO 引脚分布
- [[ELM2713 光传感器]] — LS_INT 中断源
- [[BLE GAP 广播]] — 按键 B 长按 5s 进入配网
- [[UART 基础]] — UART TX/RX 是 GPIO 的复用功能

#flashcard
问：按键为什么要"防抖"？典型防抖时间是多少？
答：机械按键按下瞬间金属弹片会抖动，导致电平在高/低之间快速跳变。软件需要延时 20-50ms 等稳定后再读。

问：GPIO "复用功能"是什么意思？
答：同一个物理引脚可以切换为"通用 IO"或"外设功能"。比如某个引脚既可以当普通 GPIO 输出，也可以复用为 UART TX 或 I2C SDA。
