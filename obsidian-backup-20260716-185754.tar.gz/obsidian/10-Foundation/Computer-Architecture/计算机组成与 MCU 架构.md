# 计算机组成与 MCU 架构

**一句话结论（20% 核心）**：MCU 就是"CPU + 存储器 + 外设 + 总线"四个东西连在一起，程序 = 从 Flash 取指令 → 在 CPU 里执行 → 读写 RAM / 外设。理解 MCU 架构，就是理解代码如何变成电信号。

---

## 第一层：核心认知

### 1.1 最小类比：MCU 是一个工厂

把 MCU 想象成一个工厂：

| 工厂里的角色 | MCU 对应 | 作用 |
|---|---|---|
| 厂长 | **CPU**（Central Processing Unit，中央处理器） | 读取图纸（指令），指挥生产 |
| 仓库 | **Flash**（闪存） | 存放图纸（程序代码），掉电不丢 |
| 工作台 | **RAM**（Random Access Memory，随机存取存储器） | 存放正在加工的材料（变量、数据） |
| 各种机器 | **外设（Peripheral）** | UART、I2C、GPIO、ADC 等功能模块 |
| 传送带 | **总线（Bus）** | 数据和指令在 CPU / RAM / 外设之间搬运 |
| 节拍器 | **时钟（Clock）** | 同步所有操作的节拍 |
| 紧急停止按钮 | **复位（Reset）** | 让一切从头开始 |

### 1.2 核心概念速查表

| 术语 | 中文 | 作用 | 备注 |
|---|---|---|---|
| CPU | 中央处理器 | 执行指令、做运算 | MCU 的大脑 |
| Flash | 闪存 | 存储程序代码 | 掉电不丢、可擦写、速度比 RAM 慢 |
| RAM | 随机存取存储器 | 存储运行时变量 | 掉电丢失、速度快 |
| Register | 寄存器 | CPU 内部的高速小存储 | 最快但极少，几十个 |
| Bus | 总线 | 地址总线 + 数据总线 + 控制总线 | 连接所有模块 |
| Clock | 时钟 | 同步节拍 | 主频越高跑得越快，功耗也越高 |
| Reset | 复位 | 回到初始状态 | 上电复位 / 看门狗复位 / 手动复位 |
| GPIO | 通用输入输出 | 最基本的引脚控制 | 控制 LED、读按键 |
| Peripheral | 外设 | UART/I2C/SPI/ADC 等功能模块 | 通过寄存器控制 |

### 1.3 最小代码示例

```c
// 向 GPIO 寄存器写入值，点亮一个 LED
volatile uint32_t *gpio_out = (volatile uint32_t *)0x40000000;
*gpio_out = 0x01;  // 第 0 位写 1，对应的引脚变高电平
```

这行代码做了什么？
1. CPU 把地址 `0x40000000` 放到**地址总线**上。
2. 总线译码器发现这个地址属于 GPIO 外设。
3. CPU 把数据 `0x01` 放到**数据总线**上。
4. GPIO 外设接收到数据，对应的引脚输出高电平。

### 1.4 如果只记得一件事

> MCU 的一切操作都是：**CPU 通过总线，对某个地址做读或写**。Flash 地址 = 取指令，RAM 地址 = 读写变量，外设地址 = 控制硬件。

---

## 第二层：实战理解

### 2.1 哈佛结构 vs 冯诺依曼结构

| 特性 | 冯诺依曼结构 | 哈佛结构 |
|---|---|---|
| 指令和数据 | 共用同一总线 | 分开两套总线 |
| 取指令和取数据 | 不能同时 | 可以同时 |
| 典型代表 | 通用 PC | ARM Cortex-M、RISC-V |
| 优势 | 简单 | 更快、流水线效率更高 |

WQ7036A 中的 RISC-V（ACORE/BCORE）和 Xtensa HiFi5（DCORE）都是**改进型哈佛结构**：指令总线和数据总线分开，可以同时取指和读写数据。

### 2.2 地址映射（Memory Map）：MCU 的"地图"

MCU 把所有的 Flash、RAM、外设都放在一个统一的**地址空间**里。每个模块占一段地址范围。

```
典型 MCU 地址映射（简化）：

0x0000_0000 ┌──────────────┐
            │   Flash       │  程序代码、常量
0x000F_FFFF └──────────────┘
0x2000_0000 ┌──────────────┐
            │   SRAM        │  变量、栈、堆
0x2001_FFFF └──────────────┘
0x4000_0000 ┌──────────────┐
            │   外设寄存器   │  GPIO/UART/I2C/SPI/...
0x4FFF_FFFF └──────────────┘
```

**怎么看地址映射表？**

1. 打开芯片的 Datasheet 或 Reference Manual，找"Memory Map"章节。
2. 每个外设都有一个**基地址（Base Address）**。
3. 外设内部的每个寄存器 = 基地址 + 偏移量（Offset）。

```c
// 示例：UART1 基地址 = 0x4001_0000
// 数据寄存器偏移 = 0x00
// 状态寄存器偏移 = 0x04
#define UART1_BASE   0x40010000
#define UART1_DR     (*(volatile uint32_t *)(UART1_BASE + 0x00))
#define UART1_SR     (*(volatile uint32_t *)(UART1_BASE + 0x04))
```

### 2.3 WQ7036A 三核架构详解

WQ7036A/AX 是一颗**异构多核**音频 SoC，包含三个不同类型的 CPU：

| 核心 | 架构 | 主要职责 | 操作系统 |
|---|---|---|---|
| **ACORE** | RISC-V（rv32imac） | 应用逻辑、FreeRTOS 任务、UI、按键 | FreeRTOS |
| **BCORE** | RISC-V | 蓝牙协议栈（BT/BLE） | 专用 RTOS |
| **DCORE** | Xtensa HiFi5（DSP） | 音频编解码、KWS（唤醒词）、降噪 | 专用固件 |

**为什么用三核而不是一个强核？**

1. **分工明确**：蓝牙协议栈对实时性要求极高，不能被应用层任务打断；音频 DSP 需要大量乘加运算，通用 CPU 做不了。
2. **功耗优化**：不需要音频处理时，DCORE 可以完全关闭。
3. **隔离性好**：一个核崩溃不影响其他核。

**三核之间怎么通信？**

通过 **IPC（Inter-Process Communication，进程间通信）**，使用共享内存 + 软中断的方式。详见 [[多核通信与 IPC]]。

### 2.4 流水线（Pipeline）

现代 CPU 不会一条指令做完再取下一条，而是把指令拆成多个阶段，像工厂流水线一样重叠执行：

```
时钟周期:   1    2    3    4    5    6
指令 A:   [取指][译码][执行][访存][写回]
指令 B:        [取指][译码][执行][访存][写回]
指令 C:             [取指][译码][执行][访存][写回]
```

这就是为什么**分支指令**（if/else、跳转）会影响性能——跳转时流水线要清空重来（pipeline flush），浪费几个时钟周期。

> 编译器会做**分支预测优化**，把大概率走的路径放在不跳转的方向。

### 2.5 中断控制器

MCU 有很多中断源（GPIO 变化、UART 接收、定时器溢出…），但 CPU 只有一个中断入口。所以需要一个**中断控制器（Interrupt Controller）** 来管理：

```
GPIO 中断 ──┐
UART 中断 ──┤
Timer 中断 ──┤──→ 中断控制器 ──→ CPU（NVIC / PLIC）
DMA 中断 ──┤      (优先级排序)
I2C 中断 ──┘
```

- **优先级（Priority）**：数字越小优先级越高，高优先级中断可以打断低优先级（中断嵌套）。
- **使能（Enable）**：每个中断都有独立的开关，不用时必须关闭。
- **挂起（Pending）**：中断发生了但 CPU 还没处理，就会挂起等待。

---

## 第三层：深入扩展

### 3.1 RISC-V vs ARM Cortex-M 对比

| 特性 | ARM Cortex-M | RISC-V |
|---|---|---|
| 指令集 | Thumb/Thumb-2（CISC 风） | RV32I/RV32IMAC（RISC） |
| 授权模式 | ARM 公司授权，收费 | 开源 ISA，免费 |
| 中断控制器 | NVIC | PLIC / CLIC |
| 调试接口 | SWD / JTAG | cJTAG / JTAG |
| 生态 | 极其成熟 | 快速成长中 |

WQ7036A 的 ACORE/BCORE 用的是 RISC-V，DCORE 用的是 Cadence Xtensa HiFi5 DSP。

### 3.2 缓存（Cache）与一致性问题

高速缓存（Cache）是 CPU 和 RAM 之间的缓冲层，用来弥补 CPU 速度远快于 RAM 的差距。

```
CPU → L1 Cache → L2 Cache → SRAM → Flash
     (最快最小)              (最慢最大)
```

**一致性问题**：当 DMA 直接写 RAM 而不经过 Cache 时，Cache 里的数据和 RAM 里的数据不一致。CPU 从 Cache 读到的是旧数据。

解决方法：
- **Clean（清洗）**：把 Cache 中的修改写回 RAM。
- **Invalidate（失效）**：把 Cache 中的旧数据标记为无效，下次从 RAM 重新取。

在 WQ7036A 的 DCORE（DSP）和 ACORE 之间共享音频缓冲区时，Cache 一致性是常见的 bug 来源。

### 3.3 总线仲裁与 DMA 总线矩阵

当多个主设备（CPU、DMA 控制器）同时要访问 RAM 时，就需要**总线仲裁**：

```
CPU ────┐
        ├──→ 总线矩阵（Bus Matrix）──→ SRAM
DMA ────┘        (谁优先级高谁先用)
```

- DMA 传输期间如果 CPU 也要访问同一块 RAM，CPU 会被**总线挂起（bus stall）**。
- 优化方法：把 DMA 和 CPU 访问的数据放在不同的 RAM Bank。

### 3.4 小端 vs 大端（Endianness）

| 类型 | 存储方式 | 典型架构 |
|---|---|---|
| 小端（Little Endian） | 低位字节在低地址 | ARM、RISC-V（默认） |
| 大端（Big Endian） | 高位字节在低地址 | 网络协议（字节序） |

```c
uint32_t val = 0x12345678;
// 小端存储：78 56 34 12（低字节在低地址）
// 大端存储：12 34 56 78（高字节在低地址）
```

**为什么重要？**
- 解析网络协议、蓝牙包时，经常需要做字节序转换。
- WQ7036A 的 RISC-V 核是小端，但蓝牙协议包中的多字节字段通常是大端，需要 `htons()` / `ntohs()` 之类的转换。

### 3.5 常见面试题

- **MCU 和 MPU 有什么区别？** MCU 集成了 Flash/RAM/外设，MPU（如手机 SoC）需要外挂。
- **为什么 Flash 比 RAM 慢？** Flash 需要擦除再写入，擦除按块（page/sector）操作，比 RAM 的字节级读写慢很多。
- **什么是 XIP（Execute In Place）？** CPU 直接从 Flash 执行代码而不拷贝到 RAM，省 RAM 但速度慢。
- **为什么有些 MCU 有多个 SRAM Bank？** 让 CPU 和 DMA 可以同时访问不同的 Bank，减少总线冲突。

### 3.6 核心术语表

| 英文 | 中文 | 说明 |
|---|---|---|
| MCU | 微控制器 | Microcontroller Unit |
| CPU | 中央处理器 | Central Processing Unit |
| Flash | 闪存 | 非易失性存储器 |
| SRAM | 静态随机存取存储器 | 掉电丢失 |
| Register | 寄存器 | CPU 内部最快存储 |
| Bus | 总线 | 数据传输通道 |
| Pipeline | 流水线 | 指令重叠执行 |
| Cache | 高速缓存 | CPU 和 RAM 之间的缓冲 |
| Memory Map | 地址映射 | 各模块的地址范围 |
| Endianness | 字节序 | 小端 / 大端 |
| NVIC | 嵌套向量中断控制器 | ARM 的中断控制器 |
| PLIC | 平台级中断控制器 | RISC-V 的中断控制器 |
| XIP | 片上执行 | Execute In Place |
| DMA | 直接内存访问 | Direct Memory Access |

### 3.7 延伸阅读

- [[编译链接与启动流程]] —— 程序怎么从 Flash 跑起来的
- [[内存管理与 DMA]] —— DMA 详解与 Cache 一致性
- [[多核通信与 IPC]] —— WQ7036A 三核怎么协作
- [[C 语言核心]] —— 指针和寄存器的关系
