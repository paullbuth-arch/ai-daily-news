---
type: moc
tags: [moc, debug, gdb, ftrace, jtag, 调试]
---

# 80-Debug: 调试方法论

> JD 能力域 10。贯穿所有能力域——"能调试"比"能写代码"更重要。

## 已有笔记

| 文件 | 核心主题 |
|------|----------|
| [[嵌入式调试方法论]] | 复现→分类→假设→验证→归档、HardFault/死锁/通信故障排查 |
| [[常用调试工具链]] | GDB/OpenOCD/逻辑分析仪/示波器 |

## 待创建

| 主题 | 预期内容 |
|------|----------|
| 串口/JTAG/SWD | 串口控制台、JTAG 连接、OpenOCD 配置 |
| GDB/ftrace | GDB 远程调试、ftrace 函数追踪、perf |
| 逻辑分析仪/示波器 | SPI/I2C/UART 协议解码、时钟/信号质量 |
| crashdump/perf | kernel panic 分析、core dump、火焰图 |
